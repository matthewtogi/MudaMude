# FrontEnd-MudaMude

Front-End MudaMude in 24 inch screen

MudaMude is a website platform based on a software engineering project in finding events and activities for youth and students

Feature 
1. Event : Find events & activities such as online webinar & seminar
2. Community : Online study & sharing with community members 
3. Partnership : Become a member & collaborate with MudaMude

Techs 
1. HTML & CSS

Prototype : https://www.figma.com/file/KLERmuGBOrjzeXYe3BMkdD/Apple-Developer-Academy---MudaMude?node-id=0%3A1
